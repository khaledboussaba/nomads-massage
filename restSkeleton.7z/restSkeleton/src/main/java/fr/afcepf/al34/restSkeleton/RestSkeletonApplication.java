package fr.afcepf.al34.restSkeleton;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestSkeletonApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestSkeletonApplication.class, args);
	}

}
